$(function () {
   ptro.hide();
   $("#createNft").click(function() {
      ptro.show();
   });
});