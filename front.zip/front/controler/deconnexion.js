function deconnexion(){
    sessionStorage.clear();
    window.location.href='http://localhost/projetNode/front/view/index.html'
}