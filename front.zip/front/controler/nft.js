//const painterro = document.getElementById("paintero");


var price = document.getElementById("prix");
var ownerLogin = sessionStorage.getItem('login');
var nftSource = null;

var ptro = Painterro({
    activeColor: '#000000',
    saveHandler: function (image) {
        nftSource = image.asDataURL()
        alert("Image créée")
        ptro.hide()
        //new QRCode(document.getElementById("qrcode"), blockchain.slice(0,100));
        //html2pdf(element);
    }
});

function sendNft(){
    const nft = document.getElementById("description").value;
    let options = {
        method: 'POST',
        url: "http://localhost:3000/nft",
        params: {
            name: nft,
            price: price.value,
            ownerLogin: ownerLogin,
            nftSource: nftSource
        }
    }

    console.log(nft)
    axios.post("http://localhost:3000/nft", {
        name: nft,
        price: price.value,
        ownerLogin: ownerLogin,
        nftSource: nftSource
    }).then((response) => {
        console.log(response);
        if (response.data.erreur) {
            // Afficher erreur
        } else {
            window.location.href='http://projetNode/front/view/index.html'
        }
    })
}
ptro.show();
