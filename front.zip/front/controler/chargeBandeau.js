// window.onload= function(){
//     console.log('bidule');
//     const avatarHaut= document.getElementById("test");
//     console.log(avatarHaut);

//     if (sessionStorage.getItem("avatar") != "") {
//         //avatarHaut.src=sessionStorage.getItem("avatar");
//         avatarHaut.src="../../front/design/img/default-avatar.jpg";
//     }else{
//         avatarHaut.src="../../front/design/img/default-avatar.jpg";
//     }
// }
    