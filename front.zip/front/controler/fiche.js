var img = document.getElementById("img");
var desc = document.getElementById("description");
var nft = JSON.parse(sessionStorage.getItem('nft'))

console.log(nft)
img.src = nft.nftSource
desc.innerText = nft.name;

var p = document.createElement("p")
p.innerText = "Vendeur:"

var span = document.createElement("span")
span.id = "pseudo"
span.innerText = nft.ownerLogin

p.appendChild(span)
span = document.createElement("span")
span.id = "imageUser"
var icon = document.createElement("img")
icon.src = "../design/img/users/user2.jpg"  // ICON A MODIFIER STATIC
span.appendChild(icon)
p.appendChild(span)
desc.appendChild(p)

function chatConnexion(){
    sessionStorage.setItem('chatLogin',nft.ownerLogin)
}