const cheminNodeJS = "http://localhost:3000/";

function modifieProfil(){
    const image= document.getElementById("image")
    //recuperer toutes les div

    //selectionner une requete AJAX parmis au moins une des 3 si les div sont remplies ou pas
    if(image.value !=""){
        let maBase64="";
        //encode l'image en base64
        const file = document.querySelector('input[type=file]')['files'][0];
        let reader = new FileReader();
        reader.onload= function (){
            maBase64=reader.result.replace("data:", "").replace(/^.+,/, "");
		    imageBase64Stringsep = maBase64;
            const login = sessionStorage.getItem("login");
            modifieAvatar(login, maBase64)
            
        }
        reader.readAsDataURL(file);
    }
}



function modifieAvatar(login, base){
    console.log(base);
    console.log(login);
    let options = {
        method: 'POST',
        url: cheminNodeJS+"ajouteAvatar",
        params: {
            reader: base,
            login: login
        }
    }


    

    axios.post(cheminNodeJS+"ajouteAvatar",{
        reader: base,
        login: login
    }).then((response) => {
        if(response.data.success){
            sessionStorage.setItem('avatar', "data:image/png;base64,"+base)
        }
        console.log(response);
    });
    

}



/*


        //lance la requete au back
        
        let options = {
            method: 'POST',
            url: cheminNodeJS+"ajouteAvatar",
            params: {
                reader: maBase64,
                login: login
            }
        }
    
        axios.request(options).then((response) => {
            console.log(response);
            if(response.data.erreur){
                //divErreur.innerHTML=response.data.erreur;
            }else{
                //sessionStorage.setItem('avatar', response.data.avatar);
    
                //window.location.href='http://localhost/projetNode/front/view/index.html'
            }
        });
    }
}
*/